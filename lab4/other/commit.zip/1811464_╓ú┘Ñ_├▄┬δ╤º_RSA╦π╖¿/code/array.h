#include <iostream>
#include <string>
#include <map>
using namespace std;

const int prime_array[21]=
            {3,5,7,11, 
            13,17,19,23,  
            29,31,37,41, 
            43,47,53,59, 
            61,67,71,73};